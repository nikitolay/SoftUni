﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Theatre.DataProcessor.ExportDto
{
    public class TicketExportModel
    {
        public decimal Price { get; set; }

        public sbyte RowNumber { get; set; }

    }
}
