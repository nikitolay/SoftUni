﻿namespace Theatre.Data
{
    public static class Configuration
    {
        public static string ConnectionString = @"Server=.;Database=TheatreExamPrep;TrustServerCertificate=True;User Id=Nikolay;Password=12345678@n;";
    }
}
